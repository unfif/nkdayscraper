<?php header("Content-Type: text/html;charset=EUC-JP") ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="ja" xml:lang="ja" id="html">
<head>
<title>
̤���� �졼����� | 2019/09/29 �滳1R �졼������(JRA) - netkeiba.com
</title>

<meta http-equiv="content-language" content="ja" />
<meta http-equiv="content-type" content="text/html; charset=euc-jp" />
<meta http-equiv="content-script-type" content="text/javascript" />
<meta http-equiv="content-style-type" content="text/css" />

<link href="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/css/common.css?2018060401" rel="stylesheet" type="text/css" media="all" />
<link href="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/css/reset.css?20160421" rel="stylesheet" type="text/css" media="all" />
<link href="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/css/win.css?20160421" rel="stylesheet" type="text/css" media="all" />
<link href="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/css/race.css?20190204" rel="stylesheet" type="text/css" media="all" />
<link href="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/css/jquery.fancybox-1.3.4.css?20160421" rel="stylesheet" type="text/css" media="all" />
<!-- link rel="stylesheet" href="https://cdn.netkeiba.com/img.www/style/netkeiba.ja/css/common_header.css" type="text/css" -->
<!--<script src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/js/jquery-1.3.2.min.js" type="text/javascript"></script>-->
<script src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/js/jquery-1.8.2.min.js?20160421" type="text/javascript"></script>
<script src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/js/jquery.cookie.js?20160421" type="text/javascript"></script>
<script src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/js/jquery.fieldtag.js?20160421" type="text/javascript"></script>
<script src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/js/fontsize.js?20160421" type="text/javascript"></script>
<script src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/js/rollover.js?20160421" type="text/javascript"></script>
<script src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/js/jquery.fancybox-1.3.4.pack.js?20160421" type="text/javascript"></script>
<script src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/js/jquery.easing-1.3.pack.js?20160421" type="text/javascript"></script>

<link rel="stylesheet" type="text/css" href="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/css/ajaxtabs.css?20160421" />
<script type="text/javascript" src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/js/ajaxtabs.js?20160421">
/***********************************************
* Ajax Tabs Content script v2.2- c Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/
</script>
<script type="text/javascript" src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/js/get_ad_request.js"></script>
<script type="text/javascript">
<!--
var _user_action_api_url = "https://user.netkeiba.com/";
var _bbs_action_api_url  = "https://bbs.netkeiba.com/";
var _raceapi_action_api_url = "https://nkraceapi.netkeiba.com/";
// -->
</script>
<script type="text/javascript" src="https://cdn.netkeiba.com/img.user/common/js/user.action.js?20160422"></script>
<script type="text/javascript" src="https://bbs.netkeiba.com//common/js/bbs.action.js?2018053101"></script>
<script type="text/javascript" src="https://cdn.netkeiba.com/img.raceapi/common/js/raceapi.action.js"></script>
<script type="text/javascript" src="https://cdn.netkeiba.com/img.regist.sp/common/js/monthly_goods_link.js?2017071901"></script>
<script src="/__utm.js" type="text/javascript"></script>

<!-- ���Υơ������ -->
<link rel="canonical" href="https://race.netkeiba.com/?pid=race&id=c201906040901&mode=result" />
<link rel="alternate" media="only screen and (max-width: 640px)" href="https://race.sp.netkeiba.com/?pid=race_result&race_id=201906040901" />
<link rel="alternate" type="application/rss+xml" href="http://rss.netkeiba.com/?pid=rss_netkeiba&site=netkeiba" />


<script src="style/netkeiba.ja/js/race_table_hover.js" type="text/javascript"></script>


</head>
<body class="race" id="race_detail">
<noscript>
�����ͤΥ֥饦���ϥ���Х�����ץȡ�JavaScript�ˤ��б����Ƥ��ʤ���̵���ˤʤäƤ��ޤ���
</noscript>
<script type="text/javascript" src="style/netkeiba.ja/js/heat.js"></script>
<div id="page">

<link rel="stylesheet" href="https://cdn.netkeiba.com/img.www/style/netkeiba.ja/css/common_header.css?2018011601" type="text/css">
<p class="sp_nk_btn disp_none"><a href="http://www.netkeiba.com/?pid=go_sp" title="���ޡ��ȥե����Ǥ�"><img src="https://cdn.netkeiba.com/img.www/style/netkeiba.ja/image/sp_nk_link_02.png" alt="���ޡ��ȥե����Ǥ�" class="imgover" /></a></p>
<header class="Header_Area fc">
<div class="Header_Inner fc">
<h1 style="padding:10px 0;">
<a href="https://www.netkeiba.com/?rf=logo" title="netkeiba.com">
<img src="https://cdn.netkeiba.com/img.www/style/netkeiba.ja/image/common/netkeiba_pc20th_logo01.png" style="width:229px" alt="netkeiba.com">
</a>
</h1>
<div class="DB_Search_Input">
<form class="Search_Box" action="https://www.netkeiba.com/" method="POST">
<input type="hidden" name="pid" value="search">
<input type="hidden" name="type" value="db">
<div class="InputTxt_Form_Box">
<input class="Txt_Form" placeholder="��̾�Ǹ���" value="" type="text" name="word" id="keywords">
</div><!-- / .InputTxt_Form -->
<div class="Submit_Btn_Box">
<input class="Submit_Btn" type="submit" name="submit" value="�� ��">
</div><!-- / .Submit_Btn_Box -->
</form>
</div><!-- / .DB_Search_Input -->
<ul class="UserMyMenu fc">

<li>
<a href="https://www.netkeiba.com/?pid=start_mypage&rf=navi">
<span>�ޥ��ڡ����Τ��Ҳ�</span>
</a>
</li>
<li>
<a href="https://race.netkeiba.com/?pid=bookmark&rf=navi" class="Icon_Header Icon_MyfavHorse">
<span>������������</span>
</a>
</li>
<li>
<a href="https://regist.netkeiba.com/account/?pid=login" class="Icon_Header Icon_Login">
<span>��������/�����Ͽ</span>
</a>
</li>
<li class="disp_none header_stage_area no_login_show">
<a href="https://regist.netkeiba.com/?pid=stage_login&action=login&return_url=https://regist.netkeiba.com/">
<span>(s)��������</span>
</a>
</li>
<li class="disp_none header_stage_area no_login_show">
<a href="https://regist.netkeiba.com/?pid=user_add_form&payment=nk_user&goods_cd=310409&opt=init">
<span>(s)̵�������Ͽ</span>
</a>
<li class="disp_none header_stage_area login_show">
<a href="https://regist.netkeiba.com/?pid=stage_login&action=logout&return_url=https://regist.netkeiba.com/">
<span>(s)����������</span>
</a>
</li>
</li>
</ul>
</div><!-- /.Header_Inner -->
</header>
<!--<div class="MenuNew01">
<span class="MenuNewIcon">NEW</span>
</div>--><!-- /.MenuNew01 -->
<nav class="ContentNavi01">
<ul class="fc">
<li class="Top">
<a href="https://www.netkeiba.com/?rf=navi" title="�ȥå�">�ȥå�</a>
</li>
<li class="News">
<a href="https://news.netkeiba.com/?rf=navi" title="�˥塼��">�˥塼��</a>
</li>
<li class="Race">
<a href="https://race.netkeiba.com/?rf=navi" title="�졼��">�졼��</a>
</li>
<li class="Yoso">
<a href="https://yoso.netkeiba.com/?access=init&rf=navi" title="���ޤ��Ϸ�">���ޤ��Ϸ�</a>
</li>
<li class="Column">
<a href="https://news.netkeiba.com/?pid=column_top&rf=navi" title="�����">�����</a>
</li>
<li class="Local">
<a href="https://nar.netkeiba.com/?rf=navi" title="��������">��������</a>
</li>
<li class="Db">
<a href="https://db.netkeiba.com/?rf=navi" title="�ǡ����١���">�ǡ����١���</a>
</li>
<li class="Books">
<a href="https://books.netkeiba.com/?rf=navi" title="�֥å���">�֥å���</a>
</li>
<li class="YosoCS">
<a href="https://orepro.netkeiba.com/?rf=navi" title="���ץ�">���ץ�</a>
</li>
<li class="Owner">
<a href="https://owner.netkeiba.com/?rf=navi" title="����ϼ�">����ϼ�</a>
</li>
<li class="Pog">
<a href="https://pog.netkeiba.com/?rf=navi" title="POG">POG</a>
</li>
<li class="Community">
<a href="https://bbs.pc.keiba.findfriends.jp/?rf=navi" title="���Ϲ���">���Ϲ���</a>
</li>
<li class="Matome">
<a href="https://dir.netkeiba.com/keibamatome/index.html?rf=navi" title="�ޤȤ�">�ޤȤ�</a>
</li>
</ul>
</nav><!-- /.ContentNavi01 -->
<!-- �����ۿ��� -->
<script async='async' src='https://www.googletagservices.com/tag/js/gpt.js'></script>
<script>
var googletag = googletag || {};
googletag.cmd = googletag.cmd || [];
</script>
<!-- /�����ۿ��� -->
<script type="text/javascript">
$(document).ready(function() {
show_user();
});
function show_user(){
var is_stage = '';
var is_user  = '';
var is_alert = '';
var is_sp    = '';
var nickname = '';
var user_img = '';
if(is_sp) {
$('.sp_nk_btn').show();
}
if(! is_stage) {
$('.header_stage_area').remove();
}
if(is_user){
//����������
$('.login_show').show();
if(is_alert) {
$('.Alert_New').show();
}
} else {
//̤��������
$('.no_login_show').show();
$('.login_show').remove();
}
}
</script>

<div class="genre_menu fc">
<ul>
<li ><a href="?pid=top" title="�졼������TOP">�졼������TOP</a></li>
<li ><a href="?pid=race_list" title="�졼������">�졼������</a></li>
<li ><a href="?pid=tendency" title="�����Υ졼������">�����Υ졼������</a></li>
<li ><a href="?pid=win5" title="WIN5">WIN5</a></li>
<li ><a href="?pid=schedule" title="�žޥ������塼��">�žޥ������塼��</a></li>
<li ><a href="/?pid=special&id=0101" title="��������"><span class="specialrace">��������</span></a></li><li ><a href="?pid=special&id=0102" title="�������ŵ"><span class="specialrace">�������ŵ</span></a></li><li ><a href="?pid=special&id=0151" title="����������ӥ�RC"><span class="specialrace">����������ӥ�RC</span></a></li>
</ul>
</div><!-- /.genre_menu -->
<div id="contents" class="fc">
<div class="race_detail_top fc">
<div id="main">
<div class="race_head">
<div class="race_head_inner">

<div class="DateList_Box">
<dl id="race_list_header" class="fc">
<dt><img alt="��������" src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/image/dt_datelist.png"></dt>
<dd><a href="/?pid=race_list&id=p0928" title="09/28(��)" >09/28(��)</a></dd><dd><a href="/?pid=race_list&id=p0929" title="09/29(��)"  class="active">09/29(��)</a></dd><dd><a href="/?pid=race_list&id=c1005" title="10/05(��)" >10/05(��)</a></dd><dd><a href="/?pid=race_list&id=c1006" title="10/06(��)" >10/06(��)</a></dd><dd><a href="/?pid=race_list&id=n1013" title="10/13(��)" >10/13(��)</a></dd>
</dl>
</div><!-- /.DateList_Box -->

<div class="race_place fc">
<ul class="fc">

<li><a href="/?pid=race&id=p201906040901&mode=result" title="�滳" class="active">�滳</a></li><li><a href="/?pid=race&id=p201909040901&mode=result" title="���">���</a></li>

</ul>
<p class="YosoCS_Link01"><a href="https://orepro.netkeiba.com/bet/shutuba.html?mode=init&race_id=201906040901" title="���ץ�">���ץ�</a></p>
</div><!-- /.race_place -->

<div class="race_num fc">
<ul class="fc">

<li><a href="/?pid=race&id=p201906040901&mode=result" title="1R" class="active">1R</a></li><li><a href="/?pid=race&id=p201906040902&mode=result" title="2R">2R</a></li>
<li><a href="/?pid=race&id=p201906040903&mode=result" title="3R">3R</a></li>
<li><a href="/?pid=race&id=p201906040904&mode=result" title="4R">4R</a></li>
<li><a href="/?pid=race&id=p201906040905&mode=result" title="5R">5R</a></li>
<li><a href="/?pid=race&id=p201906040906&mode=result" title="6R">6R</a></li>
<li><a href="/?pid=race&id=p201906040907&mode=result" title="7R">7R</a></li>
<li><a href="/?pid=race&id=p201906040908&mode=result" title="8R">8R</a></li>
<li><a href="/?pid=race&id=p201906040909&mode=result" title="9R">9R</a></li>
<li><a href="/?pid=race&id=p201906040910&mode=result" title="10R">10R</a></li>
<li><a href="/?pid=race&id=p201906040911&mode=result" title="11R">11R</a></li>
<li><a href="/?pid=race&id=p201906040912&mode=result" title="12R">12R</a></li>

</ul>
<p><a href="?pid=payback_list&id=p2019060409&mode=top" title="�滳��ʧ�����">�滳��ʧ�����</a></p>
</div><!-- /.race_num_ber -->

<div class="mainrace_data fc">
<div class="data_intro" style="margin-bottom : 15px">
<dl class="racedata fc" style="margin-bottom : 15px">
<dt>
1R
</dt>
<dd>
<h1>����̤����</h1>
<p>��1800m&nbsp;(��)</p>
<p>ŷ������&nbsp;/&nbsp;�Ͼ졧��&nbsp;/&nbsp;ȯ����10:05</p>
</dd>
</dl>
<div class="race_otherdata">
<p>2019/09/29(��)</p>
<p>4���滳9����&nbsp;����&nbsp;</p>
<p>[����]&nbsp;16Ƭ</p>
<p>�ܾ޶⡧500��200��130��75��50����</p>
</div>
<ul class="btn_link_list fc">
<li class="race_btn_IPAT">
<a href="https://ipat.netkeiba.com/?pid=ipat_input&rid=201906040901" target="_blank"><img src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/image/race_btn_ipat_on.png" alt="IPAT �Ϸ�����" class="imgover" /></a>

</li>
</ul>
</div><!-- /.race_data_intro -->
</div><!-- /.mainrace_data -->
<script language="JavaScript">
<!--
function moviepopup()
{
window.open("https://db.netkeiba.com/?pid=movie&id=201906040901", "moviepopup", "scrollbars=no,resizable=no,menubar=no,directories=no,status=no,location=no,width=650,height=460,top=100,left=" + ((screen.width/2)-400));
}
//-->
</script>

<div id="RaceSurf"></div>
<script type="text/javascript">
<!--
$( document ).ready( function() {
showRaceSurf( "RaceSurf", "201906040901" );
} );
// -->
</script>
</div><!-- /.race_head_inner -->
</div><!-- /.race_head -->
</div><!-- /#main -->
<div id="side">
<div class="side_ad">

<script language="JavaScript" type="text/javascript">noCacheParam=Math.random()*10000000000;document.write('<scr'+'ipt type="text/javascript" src="https://netdreamersad.durasite.net/A-affiliate2/mobile?site=23&keyword=new_race_rectangle&isJS=true&encoding=EUC-JP&ord=' + noCacheParam + '"></scr'+'ipt>');</script>
</div>
</div>
</div><!-- / .race_detail_top -->
<div id="race_main" class="fc">

<div class="race_deta_menu">
<ul class="main_menu fc">

<li class="race_navi_shutuba"><a href="/?pid=race_old&id=p201906040901" title="����ɽ">����ɽ</a></li>

<li class="race_navi_odds"><a href="/?pid=odds&id=p201906040901&mode=top" title="���å�">���å�</a></li>

<li class="race_navi_yoso"><a href="/?pid=yoso&id=p201906040901" title="ͽ��">ͽ��</a></li>

<li class="race_navi_chokyo"><a href="/?pid=race&id=p201906040901&mode=oikiri" title="Ĵ��">Ĵ��</a></li>

<li class="race_navi_comment"><a href="/?pid=race&id=p201906040901&mode=comment" title="���˥�����">���˥�����</a></li>

<li class="race_navi_data"><a href="/?pid=data&id=p201906040901&mode=coursedata" title="�ǡ���ʬ��">�ǡ���ʬ��</a></li>
<li class="race_navi_result"><a href="/?pid=race&id=p201906040901&mode=result" class="active" title="���/ʧ��">���/ʧ��</a></li>

<li class="race_navi_movie"><a href="https://db.netkeiba.com/?pid=movie&id=201906040901" title="�졼������">�졼������</a></li>

<li class="race_navi_bbs"><a href="/?pid=race_board&id=201906040901" title="�Ǽ���">�Ǽ���</a></li>
</ul>


</div><!-- /.race_deta_menu -->


<diary_snap>
<div class="race_result fc">
<table cellpadding="0" cellspacing="1" class="race_table_01 nk_tb_common" summary="�졼�����">
<tr>
<th>��<br />��</th>
<th style="width:1.8em;">��<br />��</th>
<th style="width:1.8em;">��<br />��</th>
<th style="width:13em;">��̾</th>
<th style="width:3em;">����</th>
<th style="width:3em;">��ô<br />����</th>
<th>����</th>
<th>������</th>
<th>�庹</th>
<th style="width:2em;">��<br />��</th>
<th style="width:5em;">ñ��<br />���å�</th>
<diary_snap_cut>
<th>��3F</th>
<th>�����ʡ�<br />�̲��</th>
</diary_snap_cut>
<th>����</th>
<th>���ν�</th>
</tr>
<tr>
<td class="result_rank">1</td>
<td class="waku8"><span>8</span></td>
<td>16</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017101894/" target="_blank">�����ġ�����</a></td>
<td>��2</td>
<td>52.0</td>
<td class="txt_l">��<a href="https://db.netkeiba.com/jockey/01167/" target="_blank">��Ȩ��</a></td>
<td>1:56.5</td>
<td></td>
<td class="r2ml">2</td>
<td class="txt_r">4.1</td>
<diary_snap_cut>
<td class="r2ml">37.9</td>
<td class="txt_l">2-2-2-1</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/01012/" target="_blank">�繾��</a></td>
<td class="txt_l">460(+8)</td>
</tr><tr>
<td class="result_rank">2</td>
<td class="waku2"><span>2</span></td>
<td>4</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017103261/" target="_blank">��������</a></td>
<td>��2</td>
<td>54.0</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/jockey/01162/" target="_blank">��Ȩ��</a></td>
<td>1:56.7</td>
<td>1.1/4</td>
<td class="bml">8</td>
<td class="txt_r">25.7</td>
<diary_snap_cut>
<td class="r1ml">37.8</td>
<td class="txt_l">5-4-4-2</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/01141/" target="_blank">����</a></td>
<td class="txt_l">460(-4)</td>
</tr><tr>
<td class="result_rank">3</td>
<td class="waku8"><span>8</span></td>
<td>15</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017103619/" target="_blank">�ϥ������ȥ����</a></td>
<td>��2</td>
<td>54.0</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/jockey/01127/" target="_blank">�ݻ�</a></td>
<td>1:56.8</td>
<td>1/2</td>
<td class="bml">6</td>
<td class="txt_r">17.6</td>
<diary_snap_cut>
<td class="r3ml">38.1</td>
<td class="txt_l">3-2-2-2</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/00405/" target="_blank">����</a></td>
<td class="txt_l">498(-4)</td>
</tr><tr>
<td class="result_rank">4</td>
<td class="waku3"><span>3</span></td>
<td>6</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017106598/" target="_blank">�٥��ȥ��ʡ�</a></td>
<td>��2</td>
<td>54.0</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/jockey/01043/" target="_blank">��¼��</a></td>
<td>1:57.9</td>
<td>7</td>
<td class="r1ml">1</td>
<td class="txt_r">2.4</td>
<diary_snap_cut>
<td class="bml">39.0</td>
<td class="txt_l">6-4-4-5</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/01051/" target="_blank">���</a></td>
<td class="txt_l">486(-2)</td>
</tr><tr>
<td class="result_rank">5</td>
<td class="waku3"><span>3</span></td>
<td>5</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017102848/" target="_blank">���٥å��ե��륹</a></td>
<td>��2</td>
<td>53.0</td>
<td class="txt_l">��<a href="https://db.netkeiba.com/jockey/01158/" target="_blank">����</a></td>
<td>1:58.1</td>
<td>1.1/2</td>
<td class="bml">7</td>
<td class="txt_r">19.9</td>
<diary_snap_cut>
<td class="bml">38.7</td>
<td class="txt_l">8-7-9-9</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/01169/" target="_blank">��ƣ��</a></td>
<td class="txt_l">480(+2)</td>
</tr><tr>
<td class="result_rank">6</td>
<td class="waku1"><span>1</span></td>
<td>1</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017103402/" target="_blank">�ե르���</a></td>
<td>��2</td>
<td>54.0</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/jockey/00684/" target="_blank">���澡</a></td>
<td>1:58.3</td>
<td>1</td>
<td class="bml">10</td>
<td class="txt_r">36.4</td>
<diary_snap_cut>
<td class="bml">38.6</td>
<td class="txt_l">10-10-13-12</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/01125/" target="_blank">����</a></td>
<td class="txt_l">522(-4)</td>
</tr><tr>
<td class="result_rank">7</td>
<td class="waku6"><span>6</span></td>
<td>12</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017104371/" target="_blank">�ȡ����󥿥��ߥ�</a></td>
<td>��2</td>
<td>54.0</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/jockey/01140/" target="_blank">������</a></td>
<td>1:58.4</td>
<td>1/2</td>
<td class="bml">14</td>
<td class="txt_r">83.9</td>
<diary_snap_cut>
<td class="bml">39.8</td>
<td class="txt_l">1-1-1-2</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/00417/" target="_blank">����</a></td>
<td class="txt_l">466(-4)</td>
</tr><tr>
<td class="result_rank">8</td>
<td class="waku7"><span>7</span></td>
<td>13</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017104133/" target="_blank">���ڥ����</a></td>
<td>��2</td>
<td>54.0</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/jockey/00660/" target="_blank">����ŵ</a></td>
<td>1:58.4</td>
<td>�ϥ�</td>
<td class="bml">5</td>
<td class="txt_r">14.5</td>
<diary_snap_cut>
<td class="r1ml">37.8</td>
<td class="txt_l">16-16-16-16</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/01165/" target="_blank">����ͦ</a></td>
<td class="txt_l">492(-2)</td>
</tr><tr>
<td class="result_rank">9</td>
<td class="waku4"><span>4</span></td>
<td>7</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017101625/" target="_blank">���ƥ�����</a></td>
<td>��2</td>
<td>54.0</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/jockey/01092/" target="_blank">��¼</a></td>
<td>1:58.4</td>
<td>����</td>
<td class="bml">15</td>
<td class="txt_r">151.7</td>
<diary_snap_cut>
<td class="bml">39.3</td>
<td class="txt_l">9-7-6-6</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/01169/" target="_blank">��ƣ��</a></td>
<td class="txt_l">506(+4)</td>
</tr><tr>
<td class="result_rank">10</td>
<td class="waku2"><span>2</span></td>
<td>3</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017106539/" target="_blank">�֥���ƥӡ���</a></td>
<td>��2</td>
<td>54.0</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/jockey/05386/" target="_blank">�ͺ귽</a></td>
<td>1:58.7</td>
<td>1.1/2</td>
<td class="r3ml">3</td>
<td class="txt_r">7.6</td>
<diary_snap_cut>
<td class="bml">39.7</td>
<td class="txt_l">3-4-6-6</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/01059/" target="_blank">��ƣ��</a></td>
<td class="txt_l">490(-4)</td>
</tr><tr>
<td class="result_rank">11</td>
<td class="waku5"><span>5</span></td>
<td>10</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017100036/" target="_blank">���ݥ������꡼</a></td>
<td>��2</td>
<td>54.0</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/jockey/01004/" target="_blank">����</a></td>
<td>1:59.0</td>
<td>2</td>
<td class="bml">16</td>
<td class="txt_r">272.0</td>
<diary_snap_cut>
<td class="bml">39.7</td>
<td class="txt_l">6-7-9-10</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/01064/" target="_blank">��ƣ</a></td>
<td class="txt_l">506(0)</td>
</tr><tr>
<td class="result_rank">12</td>
<td class="waku5"><span>5</span></td>
<td>9</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017100712/" target="_blank">���������֥롼</a></td>
<td>��2</td>
<td>54.0</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/jockey/01025/" target="_blank">����</a></td>
<td>1:59.2</td>
<td>1.1/4</td>
<td class="bml">12</td>
<td class="txt_r">66.7</td>
<diary_snap_cut>
<td class="bml">39.8</td>
<td class="txt_l">15-13-9-10</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/01027/" target="_blank">��¼</a></td>
<td class="txt_l">426(0)</td>
</tr><tr>
<td class="result_rank">13</td>
<td class="waku7"><span>7</span></td>
<td>14</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017106304/" target="_blank">�ץ��������ʥ�С�</a></td>
<td>��2</td>
<td>51.0</td>
<td class="txt_l">��<a href="https://db.netkeiba.com/jockey/01164/" target="_blank">ƣ�ĺ�</a></td>
<td>1:59.9</td>
<td>4</td>
<td class="bml">13</td>
<td class="txt_r">80.7</td>
<diary_snap_cut>
<td class="bml">40.1</td>
<td class="txt_l">10-10-13-14</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/01029/" target="_blank">����</a></td>
<td class="txt_l">478(-4)</td>
</tr><tr>
<td class="result_rank">14</td>
<td class="waku6"><span>6</span></td>
<td>11</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017101994/" target="_blank">�ޥ��ͥ�����</a></td>
<td>��2</td>
<td>54.0</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/jockey/01009/" target="_blank">������</a></td>
<td>1:59.9</td>
<td>����</td>
<td class="bml">11</td>
<td class="txt_r">60.3</td>
<diary_snap_cut>
<td class="bml">39.9</td>
<td class="txt_l">13-13-15-14</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/01079/" target="_blank">�Ų쿵</a></td>
<td class="txt_l">448(-4)</td>
</tr><tr>
<td class="result_rank">15</td>
<td class="waku1"><span>1</span></td>
<td>2</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017103305/" target="_blank">������ӡ��ϥåԡ�</a></td>
<td>��2</td>
<td>54.0</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/jockey/01096/" target="_blank">����</a></td>
<td>2:00.3</td>
<td>2.1/2</td>
<td class="bml">4</td>
<td class="txt_r">14.0</td>
<diary_snap_cut>
<td class="bml">41.2</td>
<td class="txt_l">10-10-6-8</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/01145/" target="_blank">��¼��</a></td>
<td class="txt_l">470(+2)</td>
</tr><tr>
<td class="result_rank">16</td>
<td class="waku4"><span>4</span></td>
<td>8</td>
<td class="txt_l"> <a href="https://db.netkeiba.com/horse/2017104726/" target="_blank">�饤�󥭥��ɥ�</a></td>
<td>��2</td>
<td>53.0</td>
<td class="txt_l">��<a href="https://db.netkeiba.com/jockey/01169/" target="_blank">��ƣ</a></td>
<td>2:00.5</td>
<td>1</td>
<td class="bml">9</td>
<td class="txt_r">30.2</td>
<diary_snap_cut>
<td class="bml">40.9</td>
<td class="txt_l">13-13-12-12</td>
</diary_snap_cut>
<td class="txt_l">(����)<a href="https://db.netkeiba.com/trainer/01094/" target="_blank">����</a></td>
<td class="txt_l">474(0)</td>
</tr>
</table>
<div class="fc">
<dl class="pay_block">
<dt><h3>ʧ���ᤷ</h3></dt>
<dd class="fc">
<table cellpadding="0" cellspacing="1" class="pay_table_01" summary="ʧ���ᤷ">
<tr>
<th class="tan">ñ��</th>
<td>16</td>
<td class="txt_r">410��</td>
<td class="txt_r">2�͵�</td>
</tr>
<tr>
<th class="fuku" align="center">ʣ��</th>
<td>16<br />04<br />15</td>
<td class="txt_r">180��<br />650��<br />430��</td>
<td class="txt_r">2�͵�<br />9�͵�<br />5�͵�</td>
</tr>
<tr>
<th class="waku" align="center">��Ϣ</th>
<td>02 - 08</td>
<td class="txt_r">1,000��</td>
<td class="txt_r">4�͵�</td>
</tr>
<tr>
<th class="uren" align="center">��Ϣ</th>
<td>04 - 16</td>
<td class="txt_r">5,680��</td>
<td class="txt_r">17�͵�</td>
</tr>
</table>
<table cellpadding="0" cellspacing="1" class="pay_table_01" summary="ʧ���ᤷ">
<tr>
<th class="wide">�磻��</th>
<td>04 - 16<br />15 - 16<br />04 - 15</td>
<td class="txt_r">1,880��<br />760��<br />5,210��</td>
<td class="txt_r">20�͵�<br />6�͵�<br />48�͵�</td>
</tr>
<tr>
<th class="utan">��ñ</th>
<td>16 �� 04</td>
<td class="txt_r">9,910��</td>
<td class="txt_r">31�͵�</td>
</tr>
<tr>
<th class="sanfuku">��Ϣʣ</th>
<td>04 - 15 - 16</td>
<td class="txt_r">19,590��</td>
<td class="txt_r">54�͵�</td>
</tr>
<tr>
<th class="santan">��Ϣñ</th>
<td>16 �� 04 �� 15</td>
<td class="txt_r">97,250��</td>
<td class="txt_r">280�͵�</td>
</tr>
</table>
</dd>
</dl>
<diary_snap_cut>
<dl class="corner_order">
<dt><h3>�����ʡ��̲���</h3></dt>
<dd>
<table width="100%" cellpadding="0" cellspacing="0" class="result_table_02" summary="�����ʡ��̲���">
<tr>
<th width="55">1�����ʡ�</th>
<td>(*12,16)(3,15)4(6,10)5,7(1,2,14)(8,11)9=13</td>
</tr>
<tr>
<th width="55">2�����ʡ�</th>
<td>(*12,16,15)(3,4,6)(5,7,10)(1,2,14)(8,9,11)=13</td>
</tr>
<tr>
<th width="55">3�����ʡ�</th>
<td>(*12,16,15)(4,6)(3,7,2)(5,9,10)8(1,14)11-13</td>
</tr>
<tr>
<th width="55">4�����ʡ�</th>
<td>16(12,4,15)6-(3,7)2,5(9,10)(1,8)-(11,14)-13</td>
</tr>
</table>
</dd>
</dl>
</diary_snap_cut>
</div><!-- /.fc -->
<diary_snap_cut>
<dl>
<dt><h3>��åץ�����</h3></dt>
<dd>
<table cellpadding="0" cellspacing="0" class="result_table_03" summary="��åץ�����">
<tr>
<th>200m</th><th>400m</th><th>600m</th><th>800m</th><th>1000m</th><th>1200m</th><th>1400m</th><th>1600m</th><th>1800m</th>
</tr>
<tr>
<td>12.7</td><td>12.1</td><td>13.8</td><td>14.4</td><td>12.9</td><td>12.7</td><td>12.4</td><td>12.7</td><td>12.8</td>
</tr>
<tr>
<td>12.7</td><td>24.8</td><td>38.6</td><td>53.0</td><td>65.9</td><td>78.6</td><td>91.0</td><td>103.7</td><td>116.5</td>
</tr>
</table>
</dd>
</dl>
</diary_snap_cut>
</div><!-- /.race_result -->
</diary_snap>
<div class="diary_snap_write_box">
<p style="width:146px"><a href="/?pid=diary_snapshot&snap=aHR0cDovL3JhY2UubmV0a2VpYmEuY29tLz9waWQ9cmFjZSZpZD1wMjAxOTA2MDQwOTAxJm1vZGU9dG9w&meta=race_result" title="�ҤȤ����������"><img src="style/netkeiba.ja/image/prof_btn_diary_write_01.png" class="imgover" /></a></p>
<p>�����Υ졼���ˤĤ��ơ�������񤯤��Ȥ��Ǥ��ޤ���</p>
</div><!-- /.diary_snap_write_box -->


<div class="premium_info_text_block">
<p>�� Ĵ�������Ͻžޥ졼���Τߤ��󶡤Ȥʤ�ޤ���</p>
<p>�� <img src="style/netkeiba.ja/image/icon_premium.gif" class="inline_img" /> ���Ĥ��Ƥ��륵���ӥ���<a href="http://www.netkeiba.com/premium/guide.html" id="a_monthly_goods_link_09" data-theme="01021">�ץ�ߥ��ॵ���ӥ�</a>�ˤ���Ͽ���������ޤ��Ȥ����Ѥ��������ޤ���</p>
</div><!-- /.premium_info_text_block" -->
<div class="Bnr_Baro">
<a href="//race.sp.netkeiba.com/v2/barometer/profile.html" title="Ĵ���к���">
<img src="style/netkeiba.ja/image/bnr_barometer_960_180525.jpg" alt="Ĵ���к���" />
</a>
</div>
<style>
.Bnr_Baro a:hover img {
filter: alpha(opacity=85);opacity: 0.85;-moz-opacity: 0.85;
}
</style>
<div class="mt10">

<script language="JavaScript" type="text/javascript">noCacheParam=Math.random()*10000000000;document.write('<scr'+'ipt type="text/javascript" src="https://netdreamersad.durasite.net/A-affiliate2/mobile?site=23&keyword=spat4_race&isJS=true&encoding=EUC-JP&ord=' + noCacheParam + '"></scr'+'ipt>');</script>
</div>
<div class="Contents_Box YosoGensenListBox">
<link href="https://yoso.netkeiba.com/common/css/umai_area01.css?2018031201" rel="stylesheet" type="text/css" media="all">
<div class="GensenYosoTitle">
<h2>����ͽ�� ���ޤ��Ϸ�</h2>
</div><!-- /.GensenYosoTitle -->
<div id="delay_umai_baken">
<div id="goods_view">
<div class="FileLoader"><img src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/image/gif-load.gif"></div>
</div>
</div>
</div><!-- /.Contents_Box.YosoGensenListBox -->
<script src="https://yoso.netkeiba.com/common/js/social_cart.js?2017082401" type="text/javascript"></script>
<script src="https://yoso.netkeiba.com/common/js/yoso/YosoJra.js?2017112201" type="text/javascript"></script>
<script src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/js/jquery.lazyscript.js"></script>
<script type="text/javascript">
YosoJra = new YosoJra('https://yoso.netkeiba.com/'); //yoso.action.js�򥪥֥������Ȳ�
var _show_id = 'goods_view';
var _race_id = '201906040901';
var _sort = ''; // defualt
var _limit =100;
<!--
$( document ).ready( function() {
var options = {
type: "visible",
id: "delay_umai_baken",
scripts: [
],
success: function () {
YosoJra.ShowGoodsListJraRace(_show_id, _race_id, _sort, _limit);
}
};
$.lazyscript(options);
} );
// -->
</script>


</div><!-- / #race_main -->
<div id="main">

<script language="JavaScript" type="text/javascript"> noCacheParam=Math.random()*10000000000;document.write('<scr'+'ipt type="text/javascript" src="https://netdreamersad.durasite.net/A-affiliate2/mobile?site=23&keyword=pc_nk_im&isJS=true&encoding=EUC-JP&ord=' + noCacheParam + '"></scr'+'ipt>'); </script>

<script language="JavaScript" type="text/javascript">noCacheParam=Math.random()*10000000000;document.write('<scr'+'ipt type="text/javascript" src="https://netdreamersad.durasite.net/A-affiliate2/mobile?site=23&keyword=new_race_footerleft&isJS=true&encoding=EUC-JP&ord=' + noCacheParam + '"></scr'+'ipt>');</script>

<script language="JavaScript" type="text/javascript">noCacheParam=Math.random()*10000000000;document.write('<scr'+'ipt type="text/javascript" src="https://netdreamersad.durasite.net/A-affiliate2/mobile?site=23&keyword=new_race_footerright&isJS=true&encoding=EUC-JP&ord=' + noCacheParam + '"></scr'+'ipt>');</script>

<script language="JavaScript" type="text/javascript">noCacheParam=Math.random()*10000000000;document.write('<scr'+'ipt type="text/javascript" src="https://netdreamersad.durasite.net/A-affiliate2/mobile?site=23&keyword=new_race_pic&isJS=true&encoding=EUC-JP&ord=' + noCacheParam + '"></scr'+'ipt>');</script>
</div><!-- / #main -->
<div id="side">
</div><!-- / #side -->
</div><!-- / #contents -->

<footer>
<div class="NkFooterArea">
<div class="BtnPagetop">
<a href="javascript:void(0)" title="�ڡ����ȥåפ�"></a>
</div><!-- /.BtnPagetop -->
<script type="text/javascript">
$(function() {
$('.BtnPagetop a').click(function () {
$('body,html').animate({
scrollTop: 0
}, 400);
return false;
});
});
</script>
<dl class="FootSiteTitle fc">
<dt>
<a href="https://www.netkeiba.com/?rf=footer" title="netkeiba.com">
<img src="https://cdn.netkeiba.com/img.www/style/netkeiba.ja/image/common/netkeiba_logo01.png" alt="netkeiba.com" />
</a>
</dt>
<dd>
<p>���ѼԿ�<strong>870</strong>�������ˡ�<strong>No.1</strong>���ϥ�����</p>
</dd>
</dl>
<div class="FootWrap">
<dl class="NkFoot01 NkFootCateLink">
<dt>���ƥ���</dt>
<dd class="fc">
<ul>
<li>
<a href="https://news.netkeiba.com/?rf=footer" title="�˥塼��">�˥塼��</a>
</li>
<li>
<a href="https://race.netkeiba.com/?rf=footer" title="�졼��">�졼��</a>
</li>
<li>
<a href="https://yoso.netkeiba.com/?rf=footer" title="���ޤ��Ϸ�">���ޤ��Ϸ�</a>
</li>
<li>
<a href="https://news.netkeiba.com/?pid=column_top&rf=footer" title="�����">�����</a>
</li>
<li>
<a href="https://nar.netkeiba.com/?rf=footer" title="��������">��������</a>
</li>
<li>
<a href="https://db.netkeiba.com/?rf=footer" title="�ǡ����١���">�ǡ����١���</a>
</li>
<li>
<a href="https://books.netkeiba.com/?rf=footer" title="�֥å���">�֥å���</a>
</li>
<li>
<a href="https://orepro.netkeiba.com/?rf=footer" title="���ץ�">���ץ�</a>
</li>
</ul>
<ul>
<li>
<a href="https://owner.netkeiba.com/?rf=footer" title="����ϼ�">����ϼ�</a>
</li>
<li>
<a href="https://pog.netkeiba.com/?rf=footer" title="POG">POG</a>
</li>
<li>
<a href="https://bbs.pc.keiba.findfriends.jp/?rf=footer" title="���Ϲ���">���Ϲ���</a>
</li>
<li>
<a href="https://dir.netkeiba.com/keibamatome/index.html?rf=footer" title="�ޤȤ�">�ޤȤ�</a>
</li>
<li>
<a href="https://www.netkeiba.com/paper/?rf=footer" title="���Ͽ�ʹ">���Ͽ�ʹ</a>
</li>
<li>
<a href="https://race.netkeiba.com/?pid=bookmark&rf=footer" title="������������">������������</a>
</li>
<li>
<a href="https://regist.netkeiba.com/?rf=footer" title="���������">���������</a>
</li>
</ul>
</dd>
</dl>
<dl class="NkFoot01">
<dt>�إ�ס�������</dt>
<dd>
<ul>
<li>
<a href="https://info.netkeiba.com/?rf=footer" title="���Τ餻">���Τ餻</a>
</li>
<li>
<a href="https://regist.netkeiba.com/?pid=premium&rf=footer" title="�ץ�ߥ��ॵ���ӥ��Τ�����">�ץ�ߥ��ॵ���ӥ��Τ�����</a>
</li>
<li>
<a href="https://regist.netkeiba.com/?pid=help&rf=footer" title="�褯������䡦���䤤��碌">�褯������䡦���䤤��碌</a>
</li>
</ul>
</dd>
</dl>
<dl class="NkFoot01">
<dt>netkeiba.com�ˤĤ���</dt>
<dd>
<ul>
<li>
<a href="https://www.netkeiba.com/recruit/?rf=footer" title="���Ѿ���">���Ѿ���</a>
</li>
<li>
<a href="https://www.netkeiba.com/info/ad/?rf=footer" title="����ǺܤˤĤ���">����ǺܤˤĤ���</a>
</li>
<li>
<a href="https://www.netkeiba.com/info/kiyaku.html?rf=footer" title="���ѵ���">���ѵ���</a>
</li>
<li>
<a href="https://www.netdreamers.co.jp/company/about/privacy.html?rf=footer" title="�ץ饤�Х����ݥꥷ��">�ץ饤�Х����ݥꥷ��</a>
</li>
<li>
<a href="https://www.netkeiba.com/info/guide.html?rf=footer" title="��ƥ����ɥ饤��">��ƥ����ɥ饤��</a>
</li>
<li>
<a href="https://www.netkeiba.com/info/tokusyo.html?rf=footer" title="���꾦���ˡ�˴�Ť�ɽ��">���꾦���ˡ�˴�Ť�ɽ��</a>
</li>
<li>
<a href="https://www.netdreamers.co.jp/?rf=footer" title="���Ĳ��">���Ĳ��</a>
</li>
</ul>
</dd>
</dl>
<dl class="NkFoot01">
<dt>���ޥۤ�netkeiba</dt>
<dd class="SpNkInfoImg">
<img src="https://cdn.netkeiba.com/img.www/style/netkeiba.ja/image/common/img_nk_searchimg01.png" alt="����" class="SearchImg01" />
<img src="https://cdn.netkeiba.com/img.www/style/netkeiba.ja/image/common/img_nk_qr01.png" alt="�С�������" class="QrImg01" />
</dd>
<dt>���ץ�ǥ�������netkeiba</dt>
<dd>
<ul class="AprStoreList fc">
<li>
<a href="https://itunes.apple.com/jp/app/id464562684/" title="Appstore"><img src="https://cdn.netkeiba.com/img.www/style/netkeiba.ja/image/common/bnr_appstore_01.png" alt="Appstore" class="" /></a>
</li>
<li>
<a href="https://play.google.com/store/apps/details?id=jp.co.netdreamers.netkeiba" title="googleplay"><img src="https://cdn.netkeiba.com/img.www/style/netkeiba.ja/image/common/bnr_googleplay_01.png" alt="googleplay" class="" /></a>
</li>
</ul>
</dd>
<dd class="Nk_Sns">
<ul class="fc">
<li>
<a href="https://twitter.com/netkeiba" title="���� Twitter" class="Tw"></a>
</li>
<li>
<a href="https://ja-jp.facebook.com/netkeiba" title="���� Facebook" class="Fb"></a>
</li>
<li>
<a href="https://line.me/R/ti/p/%40oa-netkeiba" title="LINE" class="Line"></a>
</li>
<li>
<a href="http://www.youtube.com/user/netkeibaTV" title="netkeiba�����ͥ�" class="Yt"></a>
</li>
<li>
<a href="https://www.instagram.com/netkeiba/" title="Instagram" class="Ig"></a>
</li>
<li>
<a href="https://www.netkeiba.com/?pid=rss" title="RSS" class="Rss"></a>
</li>
</ul>
</dd>
</dl>
</div><!-- /.FootWrap -->
</div><!-- /.NkFooterArea -->
<div class="GlobalFooterArea">
<div class="FootWrap">
<dl class="NkFoot02">
<dt class="GfootIcon01 IconGame01">netkeiba.com �������ϥ�����</dt>
<dd>
<ul>
<li>
<a href="https://chiki.netkeiba.com/?rf=footer" target='_blank' title="�������������ӡ�">�ܻؤ��Ƕ������ʡ��� <strong>�������������ӡ�</strong></a>
</li>
<li>
<a href="https://derby.pzga.jp/?rf=footer" target='_blank' title="�ѥ�������ӡ�">�ֲ������ϥѥ��륲���� <strong>�ѥ�������ӡ�</strong></a>
</li>
<li>
<a href="https://www.netkeiba.com/game/umasta.html?rf=footer" target='_blank' title="���ޤ��륹��������">�ߤ�ʤΰ��ϤȥХȥ롪 <strong>���ޤ��륹��������</strong></a>
</li>
</ul>
</dd>
</dl>
<dl class="NkFoot02">
<dt class="GfootIcon01 IconMedia01">��Ϣ��ǥ���</dt>
<dd>
<ul>
<li>
<a href="https://sp.baseball.findfriends.jp/?rf=footer" target='_blank' title="�����١����ܡ���ONLINE">Ű���ࡪ������� <strong>�����١����ܡ���ONLINE</strong></a>
</li>
<li>
<a href="https://sp.golf.findfriends.jp/?rf=footer" target='_blank' title="��å��륪��饤��">����ե�å�����󥵥��� <strong>��å��륪��饤��</strong></a>
</li>
<li>
<a href="https://recipe.sp.findfriends.jp/?rf=footer" target='_blank' title="KATSUYO�쥷��">���ӥ�����ľ���� <strong>KATSUYO�쥷��</strong></a>
</li>
<li>
<a href="https://sp.findfriends.jp/?rf=footer" target='_blank' title="Find">��̣�ǤĤʤ�������Ǽ��ĥ��ߥ�˥ƥ� <strong>Find</strong></a>
</li>
</ul>
</dd>
</dl>
<dl class="NkFoot02">
<dt class="GfootIcon01 IconSoftware01">���եȥ��������ץ�������</dt>
<dd>
<ul>
<li>
<a href="https://smart.lets-ktai.jp/?rf=footer" target='_blank' title="SMART�����">��äȤ⥻���奢��Ź�������奢�ץ� <strong>SMART�����</strong></a>
</li>
<li>
<a href="https://lets-ktai.jp/?rf=footer" target='_blank' title="Let's����������">���ޥۥ���������ASP <strong>Let's����������</strong></a>
</li>
<li>
<a href="https://webspiral.jp/?rf=footer" target='_blank' title="WEB SPIRAL">�����ȱ��Ĥ��Ū�˸�Ψ������CMS <strong>WEB SPIRAL</strong></a>
</li>
</ul>
</dd>
</dl>
</div><!-- /.FootWrap -->
<p class="CopyRight">
<small>&copy; Net Dreamers Co., Ltd.</small>
</p>
</div><!-- /.GlobalFooterArea -->
</footer>
<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-K6PJT6"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-K6PJT6');</script>
<!-- End Google Tag Manager -->
<!--
<script src="https://genieedmp.com/dmp.js?c=3335"></script>
-->
</div><!-- / #page -->

<script language="JavaScript" type="text/javascript">noCacheParam=Math.random()*10000000000;document.write('<scr'+'ipt type="text/javascript" src="https://netdreamersad.durasite.net/A-affiliate2/mobile?site=23&keyword=pc_nk_overlay&isJS=true&encoding=EUC-JP&ord=' + noCacheParam + '"></scr'+'ipt>');</script>
</body>
</html>
