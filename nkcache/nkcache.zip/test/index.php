<?php header("Content-Type: text/html;charset=EUC-JP") ?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="EUC-JP">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
</head>
<body>
  <div class="RaceList_Box fc">
    <dl class="race_top_hold_list">
      <dt class="race_top_hold_data">
        <p class="kaisaidata">4���滳9����<span class="paybacklink"><a href="/?pid=payback_list&id=p2019060409"><img src="style/netkeiba.ja/image/btn_racelist_payback.png" /></a></span></p>
        <p class="jyodata">
          ŷ��:��&nbsp;/&nbsp;��:��&nbsp;&nbsp;��:��
        </p>
      </dt>
      <dd>
        <ul>
          <li>
            <dl class="race_top_data_info fc">
              <dt><a href="/pid=race&id=p201906040901&mode=top.php" title="����̤����"><img src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/image/race_num_list_img_01_close.png" alt="1R" /></a></dt>
              <dd>
                <div class="racename">
                  <a href="/pid=race&id=p201906040901&mode=top.php" title="����̤����">����̤����</a><b id="news_201906040901"></b>
                </div>
                <div class="racedata">
                  <a href="https://db.netkeiba.com/?pid=movie&id=201906040901" title="�졼������" target="_blank"><img src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/image/icon_movie_01.gif" alt="�졼������" class="movieicon" /></a>


                  10:05&nbsp;��1800m&nbsp;16Ƭ<br />
                </div>
              </dd>
            </dl>
          </li>
          <li>
            <dl class="race_top_data_info fc">
              <dt><a href="/pid=race&id=p201906040902&mode=top.php" title="����̤����"><img src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/image/race_num_list_img_02_close.png" alt="2R" /></a></dt>
              <dd>
                <div class="racename">
                  <a href="/pid=race&id=p201906040902&mode=top.php" title="����̤����">����̤����</a><b id="news_201906040902"></b>
                </div>
                <div class="racedata">
                  <a href="https://db.netkeiba.com/?pid=movie&id=201906040902" title="�졼������" target="_blank"><img src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/image/icon_movie_01.gif" alt="�졼������" class="movieicon" /></a>


                  10:35&nbsp;��1200m&nbsp;16Ƭ<br />
                </div>
              </dd>
            </dl>
          </li>
          <li>
            <dl class="race_top_data_info fc">
              <dt><a href="/pid=race&id=p201906040903&mode=top.php" title="����̤����"><img src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/image/race_num_list_img_03_close.png" alt="3R" /></a></dt>
              <dd>
                <div class="racename">
                  <a href="/pid=race&id=p201906040903&mode=top.php" title="����̤����">����̤����</a><b id="news_201906040903"></b>
                </div>
                <div class="racedata">
                  <a href="https://db.netkeiba.com/?pid=movie&id=201906040903" title="�졼������" target="_blank"><img src="https://cdn.netkeiba.com/img.race/style/netkeiba.ja/image/icon_movie_01.gif" alt="�졼������" class="movieicon" /></a>


                  11:05&nbsp;��1600m&nbsp;16Ƭ<br />
                </div>
              </dd>
            </dl>
          </li>
        </ul>
      </dd>
    </dl>
  </div><!-- /.race_list -->
  <div class="InfoTxt_Box">
    <p>
      ����̡����ӡ����å��ʤɤΥǡ����ϡ�ɬ����ż�ȯɽ�Τ�ΤȾȹ礷����ǧ����������
    </p>
  </div>

  <!-- -->
</body>
</html>
